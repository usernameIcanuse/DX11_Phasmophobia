#include"Store.h"

void		CStore::Store(void)
{
	int iInput;
	while (true)
	{
		system("cls");
		Render();
		cout << "======================================\n";
		dynamic_cast<CPlayer*>(m_pPlayer)->Render_Inventory();
		cout << "======================================\n";
		cout << "������ ����(3.������): ";
		cin >> iInput;

		switch (iInput)
		{
		case 1:
		case 2:
			Buy(iInput - 1);
			break;
		case 3:
			return; break;
		default:
			break;
		}
	}
}


void		CStore::Buy(int _iIndex)
{
	int		_iNum;
	cout << "======================================\n";
	cout << "���� ����: ";
	cin >> _iNum;

	int		_iSum = m_Potion[_iIndex].m_iPrice * _iNum;

	if (dynamic_cast<CPlayer*>(m_pPlayer)->Get_Money() < _iSum)
	{
		cout << "�ܾ��� �����մϴ�...\n";
	}
	else {
		dynamic_cast<CPlayer*>(m_pPlayer)->Money_Minus(_iSum);
		dynamic_cast<CPlayer*>(m_pPlayer)->Get_Inventory(_iIndex, _iNum);
		cout << "���� ����!\n";
	}
	system("pause");
}

void		CStore::Render()	const
{
	cout << "=================**����**================\n";
	cout << "1. " << m_Potion[0].m_szName << "\t" << m_Potion[0].m_iPrice << "G\n";
	cout << "2. " << m_Potion[1].m_szName << "\t" << m_Potion[1].m_iPrice << "G\n";
}