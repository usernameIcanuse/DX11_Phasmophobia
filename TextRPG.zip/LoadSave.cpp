#include"LoadSave.h"

void	CMemory::Loading()
{
	dynamic_cast<CPlayer*>(m_pPlayer)->Loading();
}
void	CMemory::Saving() 
{
	dynamic_cast<CPlayer*>(m_pPlayer)->Saving();
}