#pragma once
#include"MainGame.h"

/*
void	CMainGame::Initialize(void)
{
	m_pField = new CField;
	m_pStore = new CStore;
	
	if (!m_pPlayer)
	{
		m_pPlayer = new CPlayer;
		
		dynamic_cast<CPlayer*>(m_pPlayer)->Select_Job();
	}
}
*/

void	CMainGame::Initialize(void)
{
	m_pField = new CField;
	m_pStore = new CStore;
	m_pPlayer = new CPlayer;
}

void	CMainGame::New_character(void)
{
	dynamic_cast<CPlayer*>(m_pPlayer)->Select_Job();
}

void	CMainGame::Loading(void)
{
	m_pLoadSave->Set_Player(m_pPlayer);
	m_pLoadSave -> Loading();
}


void	CMainGame::MainMenu(void)
{	
	int iMenu;
		
		system("cls");
		cout << "1. ���� �����\t2. �ҷ�����\t3.����: ";
		cin >> iMenu;
		if (iMenu == 3) return;
		Initialize();

		switch (iMenu)
		{
			case 1:
				New_character();
				//Initialize();
				break;

			case 2:
				if (m_pLoadSave == nullptr) { m_pLoadSave = new CMemory; m_pLoadSave->Set_Player(m_pPlayer); }
				Loading();
				break;

			default:
				break;
		}	
	
}

void	CMainGame::Village(void)
{
	while (1) {
		int iInput;
		system("cls");
		m_pPlayer->Render();
		cout << "======================================\n";
		//cout << "1. �����\t2. ����\t3. ������ : ";
		cout << "1. �����\t2. ����\t3. �����ϱ�\t4. ������ : ";
		cin >> iInput;

		switch (iInput)
		{
		case 1:
			m_pField->Set_Player(m_pPlayer);
			m_pField->Stage();
			break;

		case 2:
			m_pStore->Set_Player(m_pPlayer);
			m_pStore->Store();
			break;

		case 3:
			if(m_pLoadSave == nullptr){ m_pLoadSave = new CMemory; m_pLoadSave->Set_Player(m_pPlayer);}
			m_pLoadSave->Saving();
			break;
		case 4:
			return;
		default:
			break;
		}
		

	}
	
}

void CMainGame::Release(void)
{
	SAFE_RELEASE(m_pPlayer);
	SAFE_RELEASE(m_pField);
	SAFE_RELEASE(m_pStore);
	SAFE_RELEASE(m_pLoadSave);
}