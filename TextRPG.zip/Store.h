#pragma once
#include"Player.h"

class CStore
{
private:
	CObj*		m_pPlayer;
	Potion			m_Potion[2];

public:
	CStore()
	{
		m_Potion[0].m_szName = "HP����";
		m_Potion[1].m_szName = "MP����";

		m_Potion[0].m_iPrice = 100;
		m_Potion[1].m_iPrice = 100;
	}

public:
	void		Set_Player(CObj*	_pPlayer) { m_pPlayer = _pPlayer; }

public:
	void		Store(void);
	void		Buy(int _iIndex);
	void		Render()	const;
};