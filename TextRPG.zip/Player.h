#pragma once
#include "CObj.h"

class CPlayer : public CObj
{
private:
//	CObj*		m_tCObj;
	int			m_iExp;
	int			m_iExpMax;
	int			m_iMoney;
	Potion		m_iInventory[2];

public:
	CPlayer() : m_iExp(0), m_iExpMax(0)
	{
		m_iInventory[0].m_szName = "HP����";
		m_iInventory[0].m_szName = "MP����";
		m_iMoney = 1000;//default
	};
	virtual	~CPlayer() {  };
	
public:
	//CObj*		Get_CObj(void)		const;

	void		Set_Zero(void);
	void		Get_Exp(int _iExp);

public:
	virtual		void		Render(void)	const;
	virtual		void		Initialize(string _szName, int _iAttack, int _iHPMax, int _iLevel);
	void		Select_Job(void);

public:
	void		Render_Inventory(void)		const;
	int			Get_Money(void) { return m_iMoney; }
	void		Money_Minus(int _iMoney) { m_iMoney -= _iMoney; }
	void		Get_Inventory(int _iIndex, int _iNum) { m_iInventory[_iIndex].m_iNum  += _iNum; }

public:
	void		Loading(void);
	void		Saving(void);
};