#pragma once

#include "Player.h"
#include "string.h"

void	CPlayer::Initialize(string _szName, int _iAttack, int _iHPMax, int _iLevel,int iMoney)
{
	m_tInfo->m_szName = _szName;
	m_tInfo->m_iAttack = _iAttack;
	m_tInfo->m_iHP = m_tInfo->m_iHPMax = _iHPMax;
	m_tInfo->m_iLevel = _iLevel;
	m_tInfo->m_iExp = 0;
	m_tInfo->m_iExpMax = 100;
	m_tInfo->m_iMoney = iMoney;
}


void	CPlayer::Set_Zero(void)
{
	CObj::Reset_HP();
	m_tInfo->m_iExp = 0;
}

void	CPlayer::Get_Exp(int _iExp)
{
	m_tInfo->m_iExp += _iExp;
	if (m_tInfo->m_iExp >= m_tInfo->m_iExpMax)
	{
		CObj::Level_Up();
		m_tInfo->m_iExp -= m_tInfo->m_iExpMax;
		m_tInfo->m_iExpMax += 100;
	}
}


void	CPlayer::Select_Job(void)
{
	system("cls");
	int iInput;
	cout << "������ �����ϼ��� (1. ����	2. ������	3.����) :";
	cin >> iInput;

	switch (iInput)
	{
	case 1:
		Initialize("����", 20, 200, 1,1000);
		
		break;

	case 2:
		Initialize("������", 50, 100, 1,1000);
		break;

	case 3:
		Initialize("����", 10, 50, 1,1000);
		break;

	default:
		break;
	}
}

void	CPlayer::Render(void)	const
{
	cout << "����:\t" << m_tInfo->m_szName << endl;
	cout << "���ݷ�:\t" << m_tInfo->m_iAttack << endl;
	cout << "ü��:\t" << m_tInfo->m_iHP << '\t' << m_tInfo->m_iHPMax << endl;
	cout << "����:\t" << m_tInfo->m_iLevel;
	cout<< " ( " << m_tInfo->m_iExp <<" / "<< m_tInfo->m_iExpMax<<" )"<< endl;
}



void	CPlayer::Release_Inventory()
{

	if (!m_vCap.empty())
	{
		vector<CObj*>::iterator		iter = m_vCap.begin();
		for (; iter != m_vCap.end();)
		{
			SAFE_RELEASE(*iter);
			iter = m_vCap.erase(iter);
		}
	}
}

void		CPlayer::Loading(FILE*	fp)
{

	fread(m_tInfo, sizeof(Info), 1, fp);
	

	cout << "�ҷ����� �Ϸ�!" << endl;
	system("pause");

}

void		CPlayer::Saving(FILE*	fp)
{	

	fwrite(m_tInfo, sizeof(Info), 1, fp);
	
	cout << "�����Ͽ����ϴ�." << endl;
	system("pause");

}
//string �ѱ� ���ڿ� �񱳰� �ȵǳ�?



void		CPlayer::Render_Cap()
{
	if (m_vCap.empty())
	{
		cout << "������ �������� �����ϴ�.\n";
	}
	else
	{
		cout << "������ ������ :\n";
		vector<CObj*>::iterator		iter = m_vCap.begin();
		for (int i=1; iter != m_vCap.end();++i, ++iter)
		{
			cout << i << endl;
			(*iter)->Render();
			cout << "======================================\n";
		}
	}
}

bool		CPlayer::Puton_Item(CObj*  _item)
{
	bool bFlag = false;
	vector<CObj*>::iterator		iterC = m_vCap.begin();

	for (; iterC != m_vCap.end(); ++iterC)
	{
		if (static_cast<Item*>(_item)->Get_Num() == static_cast<Item*>(*iterC)->Get_Num())
		{
			cout << "�������� �ߺ� ������ �� �����ϴ�\n";
			system("pause");
			bFlag = true;
			break;
		}
	}
	
	if (bFlag || iterC != m_vCap.end()) return false;
	
	m_vCap.push_back(_item);
	m_tInfo->m_iAttack += (_item)->Get_Info().m_iAttack;
	m_tInfo->m_iHPMax += (_item)->Get_Info().m_iHP;
	return true;
	
}


CObj*		CPlayer::Putoff_Item(int  _iIndex)
{
	
	vector<CObj*>::iterator		iter = m_vCap.begin() + _iIndex - 1;
	m_tInfo->m_iAttack -= (*iter)->Get_Info().m_iAttack;
	m_tInfo->m_iHPMax -= (*iter)->Get_Info().m_iHP;
	if (m_tInfo->m_iHP > m_tInfo->m_iHPMax)
	{
		m_tInfo->m_iHP = m_tInfo->m_iHPMax;
	}
	CObj*  Temp = *iter;
	iter = m_vCap.erase(iter);

	return Temp;

}
