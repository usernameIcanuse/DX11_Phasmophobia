#pragma once
#include<iostream>
#include<string>
using namespace std;

#define SAFE_RELEASE(p) { delete p; p = nullptr;}


typedef struct  Info
{
	string		m_szName;
	int			m_iAttack;
	int			m_iHP;
	int			m_iHPMax;
	int			m_iLevel;
	int			m_iExp;
	int			m_iExpMax;
	int			m_iMoney;
	Info()
	{
		m_szName = "";
		m_iAttack = 0;
		m_iHP = 0;
		m_iHPMax = 0;
		m_iLevel = 0;
		m_iExp=0;
		m_iExpMax=0;
		m_iMoney=0;
	}
}Info;


class CObj
{
protected:
//protected�� �����ϸ� �ڽ� Ŭ������ ���ٸ� �����ϰ� �������� �Ұ���->���� �Լ� �����ؼ� ������ �׷��� ��� ���� �̿�
	Info*	m_tInfo;

public:
	CObj():m_tInfo(new Info){}
	CObj(string _szName, int _iPower, int _iShield, int _iPrice)
	{
		m_tInfo->m_szName = _szName;
		m_tInfo->m_iAttack = _iPower;
		m_tInfo->m_iHP = _iShield;
		m_tInfo->m_iMoney = _iPrice;
	}
	CObj(CObj&	Obj) {}
	virtual ~CObj(){ }

public:
	const Info&	Get_Info(void) const { return *m_tInfo; }

	void		Money_Minus(int _iMoney) { m_tInfo->m_iMoney -= _iMoney; }
	void		Money_Plus(int _iMoney) { m_tInfo->m_iMoney += _iMoney; }
	
	void		Set_Damaged(int _iAttack) { m_tInfo->m_iHP -= _iAttack; }
	void		Level_Up(void);
	void		Increase_Attack(int	_iAttack) { m_tInfo->m_iAttack += _iAttack; }
	void		Reset_HP(void){ m_tInfo->m_iHP = m_tInfo->m_iHPMax;}

	virtual		void	Initialize(string _szName, int _iAttack, int _iHPMax, int _iLevel,int iMoney) = 0;
	virtual		void	Render(void) const = 0;
	

};



