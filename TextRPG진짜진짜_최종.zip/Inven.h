#pragma once
#include"Player.h"
#include"Item.h"

class CInven
{
public:
	CInven() : m_tSize(5)
	{
		m_vInven.reserve(5);
		
	}

	~CInven()
	{
		Release();
	}
public:
	void	Set_Player(CObj* _pPlayer) { m_pPlayer = _pPlayer; }
	void	Inventory();
	void	Release();
	void	Render();

	bool	Is_Inven_Full();
	void	Delete_Item();
	void	Sell_Item(int _iIndex);
	void	Get_Item(CObj& _item);

	void		Set_Item();//������ ����,����

	void		Puton_Item();
	void		Putoff_Item();

private:
	CObj*				m_pPlayer;//�ۿ��� �޾ƿ� �����ϸ� �ȵ�
	vector<CObj*>		m_vInven;
	const size_t		m_tSize;
};