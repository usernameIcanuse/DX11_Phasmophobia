#pragma once
#include"CObj.h"


class Item : public CObj
{

public:
	Item() {}
	Item(string _szName, int _iPower, int _iShield, int _iPrice, int _iNum)
		:CObj(_szName,_iPower,_iShield,_iPrice), m_iNum(_iNum) {}

	Item(CObj&	item)
	{
		m_tInfo->m_szName = item.Get_Info().m_szName;
		m_tInfo->m_iAttack = item.Get_Info().m_iAttack;
		m_tInfo->m_iMoney = item.Get_Info().m_iMoney;
		m_tInfo->m_iHPMax= m_tInfo->m_iHP = item.Get_Info().m_iHPMax;
		m_iNum = dynamic_cast<Item*>(&item)->Get_Num();
	}

public:
	virtual void Initialize(string _szName, int _iAttack, int _iHPMax, int _iLevel, int iMoney);
	virtual void Render()	const;
	
	int Get_Num() { return m_iNum; }
	

private:
	int		m_iNum;
};
