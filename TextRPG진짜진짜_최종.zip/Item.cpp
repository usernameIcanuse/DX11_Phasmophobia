#include"Item.h"

void Item::Initialize(string _szName, int _iAttack, int _iHPMax, int _iLevel, int iMoney)
{
	m_tInfo->m_szName = _szName;
	m_tInfo->m_iAttack = _iAttack;
	m_tInfo->m_iMoney = iMoney;
	m_tInfo->m_iHP= m_tInfo->m_iHPMax = _iHPMax;
	m_iNum = _iLevel;
}

void Item::Render()	const
{
	cout << "�̸� : " << m_tInfo->m_szName << endl;
	cout << "���ݷ� ������ : " << m_tInfo->m_iAttack << endl;
	cout << "ü�� ������ : " << m_tInfo->m_iHP << endl;
	cout << "���� : " << m_tInfo->m_iMoney << endl;
}