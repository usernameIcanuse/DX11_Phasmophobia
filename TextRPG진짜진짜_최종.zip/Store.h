#pragma once
#include"Player.h"
#include"Inven.h"

enum
{
	Weapon = 1,
	Shield
};

enum
{
	Easy = 1,
	Normal,
	Hard
};

class CStore
{
private:
	CObj*		m_pPlayer;//���⼭ �����ϸ� �ȵ�
	CObj*		m_pItem[3][2];
	CInven*		m_pInven;

public:
	CStore()
	{
		for (int i = 0; i < 3; ++i)
			for (int j = 0; j < 2; ++j)
				m_pItem[i][j] = nullptr;
	}
	~CStore() { Release(); }

public:
	void		Set_Pointer(CObj*	_pPlayer, CInven* _pInven) { m_pPlayer = _pPlayer; m_pInven = _pInven; }
	void		Initialize();

public:
	void		Update();
	void		Store(void);
	
	void		Strength(void);
	void		Buy_Item(CObj&	Temp);
	void		Sell_Item();
	void		Render(int _eLevel);

	void		Release();
};