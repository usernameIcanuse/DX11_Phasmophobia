#include"Inven.h"

void CInven::Inventory()
{
	int _iMenu;

	while (1)
	{
		system("cls");
		m_pPlayer->Render();
		cout << "======================================\n";
		Render();
		cout << "======================================\n";
		cout << "1. ������ ����\t2. ������ ����/����\t3. �ڷΰ��� :  ";
		cin >> _iMenu;

		switch (_iMenu)
		{
		case 1:
			Delete_Item();
			break;

		case 2:
			Set_Item();
			break;

		case 3:
			return;

		default:
			break;

		}

	}
}


bool  CInven::Is_Inven_Full()
{
	if(m_vInven.size()<m_tSize) return false ;
	else return true;
}

void		CInven::Set_Item()
{
	int		_iInput;
	while (1)
	{
		system("cls");
		m_pPlayer->Render();
		cout << "======================================\n";
		static_cast<CPlayer*>(m_pPlayer)->Render_Cap();
		cout << "======================================\n";
		Render();
		cout << "======================================\n";
		cout << "1. ����\t2. ����\t3. �ڷΰ��� : ";
		cin >> _iInput;

		switch (_iInput)
		{
		case 1:
			Puton_Item();
			break;

		case 2:
			Putoff_Item();
			break;

		case 3:
			return;

		default:
			break;
		}
	}
}


void		CInven::Puton_Item()
{
	while (1)
	{
		bool	bFlag = false;
		int	Find;
		system("cls");
		m_pPlayer->Render();
		cout << "==========������ ������==========\n";
		static_cast<CPlayer*>(m_pPlayer)->Render_Cap();
		cout << "======================================\n";
		Render();
		cout << "======================================\n";
		cout << "������ ���(�ڷΰ����� 0�Է�) : ";
		cin >> Find;

		if (0 == Find) return;
		if (1 > Find || m_vInven.size() < Find) continue;

		vector<CObj*>::iterator		iterI = m_vInven.begin() + Find - 1;
		
		if(static_cast<CPlayer*>(m_pPlayer)->Puton_Item(*iterI))
			iterI = m_vInven.erase(iterI);
	}
}


void		CInven::Putoff_Item()
{
	while (1)
	{

		int	Find;
		system("cls");
		m_pPlayer->Render();
		cout << "======================================\n";
		static_cast<CPlayer*>(m_pPlayer)->Render_Cap();
		cout << "======================================\n";
		cout << "������ ���(�ڷΰ����� 0 �Է�) : ";
		cin >> Find;

		if (0 == Find) return;

		if (m_vInven.size() < m_tSize)
		{
			m_vInven.push_back(static_cast<CPlayer*>(m_pPlayer)->Putoff_Item(Find));
		}
		else
		{
			cout << "�κ��丮�� ���� á���ϴ�.\n";
			system("pause");
		}
	}


}

void		CInven::Get_Item(CObj&	_item)
{
	CObj*		Temp = new Item(_item);
	m_vInven.push_back(Temp);
	cout << "���� ����!\n";
}

void		CInven::Delete_Item()
{

	while (1)
	{
		system("cls");
		bool bFlag = true;
		int iIndex;

		system("cls");
		Render();
		cout << "������ ������ (�ڷΰ����� 0�Է�) : ";
		cin >> iIndex;

		if (0 == iIndex) return;
		if (1 > iIndex || m_vInven.size() < iIndex) continue;

		int iNum;
		vector<CObj*>::iterator		iter = m_vInven.begin() + iIndex - 1;
		(*iter)->Render();
		cout << "�������� �����Ͻðڽ��ϱ�?( 1.�� / 2. �ƴϿ� ) : ";
		cin >> iNum;
		if (iNum == 1)
		{
			SAFE_RELEASE(*iter);
			iter = m_vInven.erase(iter);
		}

	}
}

void		CInven::Sell_Item(int	_iIndex)
{
	vector<CObj*>::iterator		iter = m_vInven.begin() + _iIndex - 1;

	m_pPlayer->Money_Plus((*iter)->Get_Info().m_iMoney);
	SAFE_RELEASE(*iter);
	iter = m_vInven.erase(iter);

}


void CInven::Render()
{
	if (m_vInven.empty())
	{
		cout << "�κ��丮�� ��� �ֽ��ϴ�\n";
	}

	else
	{
		vector<CObj*>::iterator		iter = m_vInven.begin();
		for (int i = 1; iter != m_vInven.end(); ++i, ++iter)
		{
			cout << i << endl;
			(*iter)->Render();
			cout << "======================================\n";
		}
	}
	cout << "��� : " << m_pPlayer->Get_Info().m_iMoney << "G\n";

}

void  CInven::Release()
{
	vector<CObj*>::iterator		iter = m_vInven.begin();
	for (; iter != m_vInven.end();)
	{
		if (*iter)
		{
			SAFE_RELEASE(*iter);
		}
		iter = m_vInven.erase(iter);
	}
}