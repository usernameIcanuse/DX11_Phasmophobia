#pragma once
#include "CObj.h"
#include"Item.h"
#include<vector>

class CPlayer : public CObj
{
private:
//	CObj*		m_tCObj;

	vector<CObj*>		m_vCap;

public:
	CPlayer() 
	{
		m_vCap.reserve(2);
	}
	virtual	~CPlayer() 
	{
		Release_Inventory();
	};
	
public:
	//����
	void		Select_Job(void);
	void		Set_Zero(void);
	void		Get_Exp(int _iExp);

public:
	virtual		void		Render(void)	const;
	virtual		void		Initialize(string _szName, int _iAttack, int _iHPMax, int _iLevel, int iMoney);

public:
	//�κ��丮
	
	void		Release_Inventory();

public:
	void		Render_Cap();//���� ������

	bool		Puton_Item(CObj*  _item);
	CObj*		Putoff_Item(int  _iIndex);


public:
	//����
	void		Loading(FILE*	fp);
	void		Saving(FILE*	fp);
};